import os
import pandas as pd
import json
from collections import defaultdict
import numpy as np

disi = 3
stat_files = os.listdir(".")
stat_files.sort()
weights = {'Angst': 1006, 'Depresjon': 1038, 'Familie': 331, 'Spis': 698, 'Traume': 1154}

for stat_file in stat_files:
	if 'eval_matrix_' in stat_file: 
		method = stat_file.replace('eval_matrix_', '')
		method = method.replace('.json', '')
		total_weight = defaultdict(list)
		table = defaultdict(list)
		with open("./{}".format(stat_file)) as f:
			data = json.load(f)
			for key, value in data.items():
				for k, v in value.items():
					if k != 'F0.5':
						table[k].append(np.array(v))
						total_weight[k] += len(v)*[weights[key]]
		stat = {}
		for key, value in table.items():
			stat[key] = {}
			stat[key]['mean'] = sum(np.array(value).flatten()*np.array(total_weight[key]))/sum(total_weight[key])
			stat[key]['SD'] = np.std(np.array(value).flatten())
		jsn = json.dumps(stat)
		with open("./stats_{}.json".format(method), "w") as f:
			f.write(jsn)
			
		del jsn
		del table
