from numpy import isnan, inf, savetxt
import numpy as np
import torch
import logging
import gc

import torch.nn as nn
import torch.backends.cudnn as cudnn
from Evaluation_Matix import *
from utils import *
import model_loader
from data_loader import fetch_dataloader
from tqdm import tqdm
from datetime import datetime

class Solver:
	def __init__(self, args, model_file):
		def init_weights(m):
			if isinstance(m, nn.Linear):
				nn.init.xavier_uniform_(m.weight)
				m.bias.data.fill_(0.01)
		torch.cuda.empty_cache() 
		self.dataloaders = fetch_dataloader(args) 
		self.model = model_loader.loadModel(hyperparams = args.hyperparams, netname = args.network, channels = args.params.channels).cuda()

		self.__resume_checkpoint__(model_file)
		
	
	def validate(self):
		torch.cuda.empty_cache() 
		logging.info("Validating")
		outputs = [np.empty((0, 5), float), np.empty((0, 5), int), np.empty((0, 2), int), np.empty((0, 90), int), np.empty((0,), int)]
		# switch to evaluate mode
		self.model.eval()
		#with tqdm(total=len(self.dataloaders)) as t:
		for i, (ids, datas, label) in (enumerate(self.dataloaders)):
			logging.info("        Compute output")
			output = self.model(torch.autograd.Variable(datas.cuda())).double().cpu().data.numpy()
			outputs[0] = np.concatenate((outputs[0], output), axis=0)
			outputs[1] = np.concatenate((outputs[1], torch.autograd.Variable(label[:, :-1].cuda()).int().cpu().data.numpy()), axis=0)
			
			outputs[2] = np.concatenate((outputs[2], torch.autograd.Variable(ids.cuda()).int().cpu().data.numpy()), axis=0)
			outputs[3] = np.concatenate((outputs[3], torch.autograd.Variable(datas.cuda()).int().cpu().data.numpy()), axis=0)
			outputs[4] = np.concatenate((outputs[4], torch.autograd.Variable(label[:, -1].cuda()).int().cpu().data.numpy()), axis=0)
			del output
			
			gc.collect()
			#t.update()
		outputs = predict(outputs)
		outputs = self.__get_errored_datapoint(outputs)
		
		return outputs, self.dataloaders.dataset.lab
		
	def __get_errored_datapoint(self, outputs):
		error = 1-(outputs[0]==outputs[1])
		error = np.sum(error, axis = 1)
		error_ind = np.where(error > 0)[0]
		output = [ [], [], [], [], []]
		output[0] = outputs[0][error_ind]
		for i in range(len(outputs)):
			output[i] = outputs[i][error_ind]
			
		return output
			


	def __resume_checkpoint__(self, checkpointfile):
		
		if not os.path.isfile(checkpointfile):
			return
		else:
			logging.info("Loading checkpoint {}".format(checkpointfile))
			checkpoint = torch.load(checkpointfile)
			self.model.load_state_dict(checkpoint['state_dict'])
			return 

