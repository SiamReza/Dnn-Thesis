python3 analyze.py

