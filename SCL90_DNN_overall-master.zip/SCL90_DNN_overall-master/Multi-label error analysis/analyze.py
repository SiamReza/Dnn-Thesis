import argparse

import torch
import logging
import os

import numpy as np
from itertools import permutations, product
from Solver import Solver
import torch.backends.cudnn as cudnn
from model_loader import get_model_list
from Evaluation_Matix import get_eval_multi
from collections import defaultdict
import json
from tqdm import tqdm
from utils import *

CUDA_VISIBLE_DEVICES = 0

def str2bool(v):
    if isinstance(v, bool):
       return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')
        
parser = argparse.ArgumentParser(description='PyTorch Deep Neural Net Training')

parser.add_argument('--model_dir', default='./Model', 
			help="Directory containing params.json")

parser.add_argument('--network', type=str, default = '',
			help='select network to train on. leave it blank means train on all model')
			
parser.add_argument('--log', default='warning', type=str,
			help='set logging level')




def main():
	assert torch.cuda.is_available(), "ERROR! GPU is not available."
	cudnn.benchmark = True
	args = parser.parse_args()
	netlist = get_model_list(args.network)
	eval_matrix = defaultdict(list)
	with tqdm(total=len(netlist)*20) as t:
		for network in netlist:
			args.network = network
			set_logger(args.model_dir, args.network, args.log)
			Network_dir = os.path.join(args.model_dir, network)
			Network_dir = os.path.join(Network_dir, 'Checkpointsbest')
			Model_files = os.listdir(Network_dir)
			args.params = set_params(args.model_dir, network, paramtype = 'params')
			args.hyperparams = Params(model_dir = args.model_dir, network = network, paramtype = 'Hyperparams')
			
			for model_file in Model_files:
				logging.info('error analysis with model {}'.format(model_file))
				
				cv_iter = model_file[-13:-10]
				solver = Solver(args, os.path.join(Network_dir, model_file))
				
				output, label = solver.validate()
				
				append_matrix(eval_matrix, output, label, cv_iter, network)
				t.set_postfix(network = network)
				t.update()
				
	save_matrix_to_scv(eval_matrix)


def append_matrix(matrix, output, label, cv_iter, network):
	assert output[0].shape[1] == 5, 'predict result is incomplete'
	assert output[1].shape[1] == 5, 'true result is incomplete'
	assert output[2].shape[1] == 2, 'id is incomplete'
	assert output[3].shape[1] == 90, 'feature is incomplete'
	
	matrix['No.'] = matrix['No.'] + list(output[2][:, 0])
	matrix['ID'] = matrix['ID'] + list(output[2][:, 1])
	matrix['cv_iter'] = matrix['cv_iter'] + [cv_iter] * len(list(output[2][:, 0]))
	matrix['network'] = matrix['network'] + [network] * len(list(output[2][:, 0]))
	matrix['disease'] = matrix['disease'] + [label[i] for i in output[4]]
	i = 0
	for lab in label:
		matrix['True_{}'.format(lab)] = matrix['True_{}'.format(lab)] + list(output[1][:, i])
		matrix['Predict_{}'.format(lab)] = matrix['Predict_{}'.format(lab)] + list(output[0][:, i])
		i += 1
		
	for i in range(output[3].shape[1]):
		matrix['Q_{}'.format(i+1)] = matrix['Q_{}'.format(i+1)] + list(output[3][:, i])
	

		
if __name__ == '__main__':
	os.environ["CUDA_VISIBLE_DEVICES"]="0"
	main()
