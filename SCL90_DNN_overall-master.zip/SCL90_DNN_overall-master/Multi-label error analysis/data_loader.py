import os

import numpy as np
from torch.utils.data import Dataset, DataLoader
from torch import Tensor, cuda
from itertools import chain
import torchvision.transforms as transforms
import pandas as pd


class DatasetWrapper:
	class __DatasetWrapper:
		"""
		A standard PyTorch definition of Dataset which defines the functions __len__ and __getitem__.
		"""
		def __init__(self):
			"""
			create df for features and labels
			remove samples that are not shared between the two tables
			"""

			ids = ['no', 'id']
			label = ['code']
			disease = ['disease']
			phase = ['phase']
			feature = []
			for i in range(1, 91):
				feature.append('Q{}'.format(i))
			df = pd.read_csv('SCL90Cleaned.csv', header = 0, on_bad_lines='skip', usecols = ids + label + disease + phase + feature)
			df = df.dropna()
			
			self.ids = df[ids].to_numpy()
			self.features = df[feature].to_numpy()
			self.phases = df[phase].to_numpy()
			self.disease = df[disease].to_numpy()
			
			labels = df[label].to_numpy()
			disease = df[label+disease].to_numpy()
			label = {}
			for key, value in  np.unique(disease.astype("<U22"), axis=0):
				label[int(key)] = value
			self.label = []
			
			for key in np.unique(labels):
				self.label.append(label[key])
			

	instance = None
	def __init__(self):
		if not DatasetWrapper.instance:
			DatasetWrapper.instance = DatasetWrapper.__DatasetWrapper()
		self.length = len(DatasetWrapper.instance.ids)
		self.lab = DatasetWrapper.instance.label
		

	def __getattr__(self, name):
		return getattr(self.instance, name)

	def features(self, key):
		"""
		Args: 
			key:(string) value from dataset	
		Returns:
			features in list	
		"""
		return DatasetWrapper.instance.features[key]

	def label(self, key):
		"""
		Args: 
			key:(string) the sample key/id	
		Returns:
			label of the condition
		"""
		ind = np.arange(len(DatasetWrapper.instance.label))
		ind = ind[np.where(DatasetWrapper.instance.label == DatasetWrapper.instance.disease[key])[0][0]]
		lab = np.zeros(len(DatasetWrapper.instance.label) + 1 )
		if self.phases[key] != 'Utskriving':
			lab[ind] = 1
		lab[-1] = ind
		return lab
		
	def ids(self, key):
		"""
		Args: 
			key:(string) value from dataset	
		Returns:
			patient id of the datapoint
		"""
		return DatasetWrapper.instance.ids[key]
		




		


class imageDataset(Dataset):
	"""
	A standard PyTorch definition of Dataset which defines the functions __len__ and __getitem__.
	"""
	def __init__(self):
		"""
		initialize DatasetWrapper
		"""
		self.DatasetWrapper = DatasetWrapper()
		self.lab = self.DatasetWrapper.lab


	def __len__(self):
		# return size of dataset
		return self.DatasetWrapper.length



	def __getitem__(self, idx):
		"""
		Fetch feature and labels from dataset using index of the sample.

		Args:
		    idx: (int) index of the sample

		Returns:
		    feature: (Tensor) feature array
		    label: (int) corresponding label of sample
		"""
		ids = Tensor(self.DatasetWrapper.ids(idx).astype(np.uint8))
		
		data = Tensor(self.DatasetWrapper.features(idx).astype(np.uint8))
		
		label = Tensor(self.DatasetWrapper.label(idx).astype(np.uint8))

		return ids, data, label


def fetch_dataloader(args):
	"""
	Fetches the DataLoader object for each type in types.

	Args:
	
	Returns:
	data: (dict) contains the DataLoader object for each type in types
	"""
		

	dl = DataLoader(imageDataset(), 
			batch_size = 10000, 
			shuffle = True,
			num_workers = 5,
			pin_memory = cuda.is_available())


	return dl
