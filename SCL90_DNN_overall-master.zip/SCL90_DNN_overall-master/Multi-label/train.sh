#python3 train.py --train True --resume True --network layer1
#python3 train.py --train True --resume True --network layer2
python3 train.py --train True --resume True --network layer3
python3 train.py --train True --resume True --network layer4
