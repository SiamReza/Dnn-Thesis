#python3 Hyperparam_search.py --train True --network layer1 
#python3 Hyperparam_search.py --train True --network layer2
#python3 Hyperparam_search.py --train True --network layer3 
#python3 Hyperparam_search.py --train True --network layer4 
